﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Set up default selections or messages
                lblVacationMessage.Text = "Select a date to see if it's a vacation day!";
            }
        }

        protected void vacationCalendar_SelectionChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = vacationCalendar.SelectedDate;
            lblSelectedDate.Text = "Selected Date: " + selectedDate.ToShortDateString();

            // Check if the selected date is a vacation day
            if (IsVacationDay(selectedDate))
            {
                lblVacationMessage.Text = "Hooray! It's a vacation day!";
            }
            else
            {
                lblVacationMessage.Text = "Sorry, it's not a vacation day.";
            }
        }

        protected void vacationCalendar_DayRender(object sender, DayRenderEventArgs e)
        {
            // Highlight vacation days
            if (IsVacationDay(e.Day.Date))
            {
                e.Cell.Attributes["class"] = "highlight"; // Add a CSS class for vacation days
            }
        }

        private bool IsVacationDay(DateTime date)
        {
            // Define some vacation days
            DateTime[] vacationDays = {
                new DateTime(DateTime.Now.Year, 7, 4),   // July 4
                new DateTime(DateTime.Now.Year, 12, 25),  // December 25
                new DateTime(DateTime.Now.Year, 10, 29),
                new DateTime(DateTime.Now.Year, 10, 30),
                new DateTime(DateTime.Now.Year, 10, 31),
                new DateTime(DateTime.Now.Year, 11, 1),
                new DateTime(DateTime.Now.Year, 11, 2),
                new DateTime(DateTime.Now.Year, 11, 3),
            };

            foreach (var vacation in vacationDays)
            {
                if (date.Date == vacation.Date)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
