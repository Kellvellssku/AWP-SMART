﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Practical_9_b
{
    public partial class WebForm1 : Page
    {
        // Called when the page loads
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Load data into the DetailsView when the page first loads
                DetailsView1.DataBind();
            }
        }

        // Handle FormView Insert and Update operations
        protected void FormView1_ItemCommand(object sender, FormViewCommandEventArgs e)
        {
            if (e.CommandName == "Insert")
            {
                // Get the values from the Insert form
                FormView fv = (FormView)sender;
                TextBox txtName = (TextBox)fv.FindControl("NameTextBox");
                TextBox txtEsalary = (TextBox)fv.FindControl("EsalaryTextBox");

                string name = txtName.Text;
                decimal esalary = Convert.ToDecimal(txtEsalary.Text);

                // Insert the new record into the database
                SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connStr"].ToString());
                SqlCommand cmd = new SqlCommand("INSERT INTO Employee (Name, Esalary) VALUES (@Name, @Esalary)", conn);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Esalary", esalary);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                // Rebind the DetailsView after insertion
                DetailsView1.DataBind();
            }
            else if (e.CommandName == "Update")
            {
                // Get the values from the Edit form
                FormView fv = (FormView)sender;
                TextBox txtName = (TextBox)fv.FindControl("NameTextBox");
                TextBox txtEsalary = (TextBox)fv.FindControl("EsalaryTextBox");
                int employeeId = Convert.ToInt32(e.CommandArgument); // Retrieve EmployeeId from DataKeyNames

                string name = txtName.Text;
                decimal esalary = Convert.ToDecimal(txtEsalary.Text);

                // Update the record in the database
                SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connStr"].ToString());
                SqlCommand cmd = new SqlCommand("UPDATE Employee SET Name = @Name, Esalary = @Esalary WHERE EmployeeId = @EmployeeId", conn);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Esalary", esalary);
                cmd.Parameters.AddWithValue("@EmployeeId", employeeId);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                // Rebind the DetailsView after updating
                DetailsView1.DataBind();
            }
        }
    }
}
