﻿CREATE TABLE Employee (
    EmployeeId INT PRIMARY KEY,
    Name NVARCHAR(100),
    Esalary DECIMAL(18,2)
);

INSERT INTO Employee (EmployeeId, Name, Esalary)
VALUES (1, 'Abhishek Singh', 50000),
       (2, 'Sachin Prabhu', 55000);

