﻿using System;

// Declare a delegate that can reference methods that take two integers and return void
public delegate void MathOperation(int n1, int n2);

class DelegateMethod
{
    // Method to perform addition
    public void Add(int n1, int n2)
    {
        Console.WriteLine("Addition = " + (n1 + n2));
    }

    // Method to perform subtraction
    public void Sub(int n1, int n2)
    {
        Console.WriteLine("Subtraction = " + (n1 - n2));
    }
}

class Program
{
    public static void Main(string[] args)
    {
        // Create an instance of the class containing the methods
        DelegateMethod dm = new DelegateMethod();

        // Create delegate instances and assign the methods
        MathOperation addDelegate = new MathOperation(dm.Add);
        MathOperation subDelegate = new MathOperation(dm.Sub);

        // Invoke the delegates
        addDelegate(10, 20);   // This will call dm.Add(10, 20)
        subDelegate(20, 10);   // This will call dm.Sub(20, 10)

        // Wait for user input to close the console
        Console.ReadKey();
    }
}
