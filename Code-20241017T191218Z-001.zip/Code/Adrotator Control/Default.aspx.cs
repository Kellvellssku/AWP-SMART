﻿using System;
using System.Web.UI;

namespace YourNamespace
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Any additional code can go here
        }
    }
}
