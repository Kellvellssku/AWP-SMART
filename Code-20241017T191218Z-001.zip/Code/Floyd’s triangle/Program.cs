﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter the number of rows for Floyd's Triangle: ");
        int numRows = Convert.ToInt32(Console.ReadLine());

        int number = 1;

        for (int i = 1; i <= numRows; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write(number + " ");
                number++;
            }
            Console.WriteLine();
        }

        // Pause the console so the user can see the results
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}