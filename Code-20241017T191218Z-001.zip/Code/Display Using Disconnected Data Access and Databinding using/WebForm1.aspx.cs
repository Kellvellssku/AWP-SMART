﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI;

namespace Practical_6.b
{
    public partial class WebForm1 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // No specific logic needed on Page Load for now.
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string connStr = WebConfigurationManager.ConnectionStrings["connStr"].ConnectionString;
                if (string.IsNullOrEmpty(connStr))
                {
                    Label2.Text = "Connection string not found!";
                    return;
                }

                using (SqlConnection con = new SqlConnection(connStr))
                {
                    con.Open();
                    string sql = "SELECT * FROM Employee WHERE Esalary > @Salary";
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        if (decimal.TryParse(TextBox1.Text, out decimal salary))
                        {
                            cmd.Parameters.AddWithValue("@Salary", salary);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);

                            if (ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
                            {
                                Label2.Text = "No records found.";
                            }
                            else
                            {
                                GridView1.DataSource = ds.Tables[0];
                                GridView1.DataBind();
                            }
                        }
                        else
                        {
                            Label2.Text = "Please enter a valid salary.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Label2.Text = "Invalid Query: " + ex.Message;
            }
        }
    }
}
