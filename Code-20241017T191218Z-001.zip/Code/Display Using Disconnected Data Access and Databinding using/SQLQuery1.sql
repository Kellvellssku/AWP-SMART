﻿CREATE TABLE Employee (
    EmployeeID INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(100),
    Esalary DECIMAL(18, 2)
);

-- Sample Data
INSERT INTO Employee (Name, Esalary) VALUES ('Sachin Prabhu', 50000);
INSERT INTO Employee (Name, Esalary) VALUES ('Abhishek Singh', 60000);
INSERT INTO Employee (Name, Esalary) VALUES ('Aditya Prajapati', 70000);
