﻿using System;

namespace MasterPageDemo
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Any specific logic can go here
        }
    }
}
