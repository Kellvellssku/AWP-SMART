﻿--Create a new database named TYDatabase.
--Run the following SQL script to create a Customer table:

--First CMD :-

CREATE TABLE Customer (
    Cust_Id INT PRIMARY KEY,
    Cust_Name NVARCHAR(100),
    State NVARCHAR(50),
    City NVARCHAR(50)
);

--Second CMD :-

INSERT INTO Customer (Cust_Id, Cust_Name, State, City)
VALUES (1, 'Aditya', 'Maharashtra', 'Mumbai'),
       (2, 'Pamu', 'Maharashtra', 'MumbaI');

--If you Want Add again in Customer

USE TYDatabase;  -- Make sure you're using the correct database
GO

CREATE TABLE Customer (
    Cust_Id INT PRIMARY KEY,
    Cust_Name NVARCHAR(100),
    State NVARCHAR(50),
    City NVARCHAR(50)
);


INSERT INTO Customer (Cust_Id, Cust_Name, State, City)
VALUES (1, 'Aditya', 'Maharashtra', 'Mumbai'),
       (2, 'Pamu', 'Maharashtra', 'MumbaI');

       Select*From Customer;