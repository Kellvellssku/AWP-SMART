﻿using System;
using System.Web.UI;

namespace New_Pract_6a
{
    public partial class WebForm1 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // You can add additional logic here if needed.
        }
    }
}
