﻿using System;
using System.Web.UI;

namespace New_Pract_8_b
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                // Throwing the custom exception
                throw new UserDefinedException("New User Defined Exception");
            }
            catch (UserDefinedException ex) // Catching the custom exception
            {
                Label1.CssClass = "error-message";  // Apply error style
                Label1.Text = "<b>Exception caught here: </b>" + ex.Message;
            }
            catch (Exception ex) // Catching any other exceptions
            {
                Label1.CssClass = "error-message";  // Apply error style
                Label1.Text = "<b>Exception caught here: </b>" + ex.ToString();
            }

            // Final statement
            Label2.CssClass = "info-message";  // Apply info style
            Label2.Text = "Final Statement that is executed";
        }

        // Custom exception class
        class UserDefinedException : Exception
        {
            public UserDefinedException(string message) : base(message)
            {
                // Optionally, log the exception message or perform other actions
            }
        }
    }
}
