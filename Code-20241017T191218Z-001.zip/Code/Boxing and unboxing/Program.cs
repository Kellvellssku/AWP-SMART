﻿using System;

class Program
{
    public static void Main (string[] args)
    {
        int a = 10;
        Object obj = a;
        Console.WriteLine ("a={0}",a);
        Console.WriteLine ("obj={0}",obj);
        int b = (int)obj;
        Console.WriteLine ("b={0}",b);
        Console.ReadKey ();
    }
}