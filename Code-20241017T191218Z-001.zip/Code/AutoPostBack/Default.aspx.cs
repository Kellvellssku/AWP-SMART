﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialization code can go here if needed
            }
        }

        protected void ddlFruits_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblSelectedFruit.Text = "Selected Fruit: " + ddlFruits.SelectedValue;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblOutput.Text = "You Typed: " + txtInput.Text;
        }
    }
}
