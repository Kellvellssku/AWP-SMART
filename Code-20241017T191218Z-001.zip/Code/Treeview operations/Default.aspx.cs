﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialize the TreeView with some nodes
                TreeNode rootNode = new TreeNode("Root Node");
                TreeNode childNode1 = new TreeNode("Child Node 1");
                TreeNode childNode2 = new TreeNode("Child Node 2");
                rootNode.ChildNodes.Add(childNode1);
                rootNode.ChildNodes.Add(childNode2);
                tvNodes.Nodes.Add(rootNode);
            }
        }

        protected void btnAddNode_Click(object sender, EventArgs e)
        {
            if (tvNodes.SelectedNode != null && !string.IsNullOrEmpty(txtNodeText.Text))
            {
                // Create a new node and add it to the selected node
                TreeNode newNode = new TreeNode(txtNodeText.Text);
                tvNodes.SelectedNode.ChildNodes.Add(newNode);
                txtNodeText.Text = string.Empty; // Clear the text box
            }
        }

        protected void btnDeleteNode_Click(object sender, EventArgs e)
        {
            if (tvNodes.SelectedNode != null && tvNodes.SelectedNode.Parent != null)
            {
                // Remove the selected node from its parent
                tvNodes.SelectedNode.Parent.ChildNodes.Remove(tvNodes.SelectedNode);
            }
        }

        protected void tvNodes_SelectedNodeChanged(object sender, EventArgs e)
        {
            // You can perform additional actions when a node is selected
            // For example, updating the text box with the selected node's text
            txtNodeText.Text = tvNodes.SelectedNode.Text;
        }
    }
}
