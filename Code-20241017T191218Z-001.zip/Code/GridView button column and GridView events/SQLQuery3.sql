﻿CREATE TABLE Employee(
    Eid INT PRIMARY KEY,
    Ename VARCHAR(100),
    Esalary DECIMAL(10, 2)
);

--Add data in table

INSERT INTO Employee (Eid, Ename, Esalary)
VALUES 
    (1, 'Aditya Prajapati', 60000.00),
    (2, 'Sachin Prabhu', 50000.00),
    (3, 'Abhishek Singh', 52000.00),
    (4, 'Priyanshu Vishwakarma', 40000.00),
    (5, 'Arshiyan Khan', 45000.00),
    (6, 'MD Kaish', 35000.00);


--The below code is for Check the table

SELECT * FROM Employee;
