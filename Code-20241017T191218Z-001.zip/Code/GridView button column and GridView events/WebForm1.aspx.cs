﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical_9_a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Code to load data initially
                GridView1.DataBind();
            }
        }

        // Handling GridView Paging
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataBind();
        }

        // Handling GridView Sorting
        protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sortExpression = e.SortExpression;
            // Toggle sorting direction
            string sortDirection = ViewState["SortDirection"] as string == "ASC" ? "DESC" : "ASC";
            ViewState["SortDirection"] = sortDirection;

            // Apply sorting
            SqlDataSource1.SelectCommand = "SELECT Eid, Ename, Esalary FROM Employee ORDER BY " + sortExpression + " " + sortDirection;
            GridView1.DataBind();
        }
    }
}
