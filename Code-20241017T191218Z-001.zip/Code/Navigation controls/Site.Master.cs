﻿using System;
using System.Web.UI;

namespace Practical_5.a
{
    public partial class Site : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
    }
}
