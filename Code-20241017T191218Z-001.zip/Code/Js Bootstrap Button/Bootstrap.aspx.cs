﻿using System;
using System.Web.UI;

namespace BootstrapDemo
{
    public partial class Bootstrap : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // You can add any server-side code here, but it's not needed for this demo.
        }
    }
}
