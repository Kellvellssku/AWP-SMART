﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Practical_8
{
    public partial class Pract_8a : System.Web.UI.Page
    {
        // Page Load method: Bind the DropDownList only once when the page is first loaded
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Bind the DropDownList to the employee IDs from SqlDataSource
                DropDownList1.DataSource = SqlDataSource2;
                DropDownList1.DataTextField = "Eid";
                DropDownList1.DataValueField = "Eid";
                DropDownList1.DataBind();
            }
        }

        // Insert button click event: Insert a new employee record into the database
        protected void Button1_Click(object sender, EventArgs e)
        {
            // Validate input fields to make sure all values are provided
            if (string.IsNullOrEmpty(TextBox1.Text) || string.IsNullOrEmpty(TextBox2.Text) || string.IsNullOrEmpty(TextBox3.Text))
            {
                Label5.Text = "Please fill all fields.";
                return;
            }

            // Prepare SQL query for inserting the new employee record
            string insertQuery = "INSERT INTO Employee2 (Eid, Ename, Esalary) VALUES (@Eid, @Ename, @Esalary)";

            // Using a connection string from the configuration file
            using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connStr2"].ToString()))
            {
                try
                {
                    // Open the connection
                    conn.Open();

                    // Create a command object and define the insert query with parameters
                    SqlCommand cmd = new SqlCommand(insertQuery, conn);
                    cmd.Parameters.AddWithValue("@Eid", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@Ename", TextBox2.Text);
                    cmd.Parameters.AddWithValue("@Esalary", TextBox3.Text);

                    // Execute the insert command
                    cmd.ExecuteNonQuery();
                    Label5.Text = "Employee added successfully.";

                    // Re-bind the DropDownList to show the new employee
                    DropDownList1.DataBind();

                    // Clear the input fields
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox3.Text = "";
                }
                catch (Exception ex)
                {
                    Label5.Text = "Error: " + ex.Message;
                }
            }
        }

        // Delete button click event: Delete the selected employee from the database
        protected void Button2_Click(object sender, EventArgs e)
        {
            // Validate if an employee is selected for deletion
            if (DropDownList1.SelectedValue == "")
            {
                Label5.Text = "Please select an employee to delete.";
                return;
            }

            // Prepare SQL query for deleting the selected employee record
            string deleteQuery = "DELETE FROM Employee2 WHERE Eid = @Eid";

            // Using a connection string from the configuration file
            using (SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["connStr2"].ToString()))
            {
                try
                {
                    // Open the connection
                    conn.Open();

                    // Create a command object and define the delete query with parameters
                    SqlCommand cmd = new SqlCommand(deleteQuery, conn);
                    cmd.Parameters.AddWithValue("@Eid", DropDownList1.SelectedValue);

                    // Execute the delete command
                    cmd.ExecuteNonQuery();
                    Label5.Text = "Employee deleted successfully.";

                    // Re-bind the DropDownList to reflect the deletion
                    DropDownList1.DataBind();
                }
                catch (Exception ex)
                {
                    Label5.Text = "Error: " + ex.Message;
                }
            }
        }
    }
}
