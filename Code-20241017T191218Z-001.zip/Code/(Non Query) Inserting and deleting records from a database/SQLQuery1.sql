﻿CREATE TABLE Employee2 (
    Eid INT PRIMARY KEY,
    Ename VARCHAR(100),
    Esalary DECIMAL(10, 2)
);

--The below code is for Check the table

SELECT * FROM Employee2;
