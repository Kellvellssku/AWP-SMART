﻿using System;
using System.Web.UI;

namespace Practical_10
{
    public partial class pract_10_B : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Optionally, you can initialize some page state here
        }

        // Button1_Click: Updates the label outside of the UpdatePanel (full page refresh)
        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox1.Text;
            Label1.Text = "Hello, " + name;
        }

        // Button2_Click: Updates the label inside the UpdatePanel (partial page refresh)
        protected void Button2_Click(object sender, EventArgs e)
        {
            string surname = TextBox2.Text;
            Label2.Text = "Hello, " + surname;
        }

        // Timer1_Tick: Updates the time label every 10 seconds
        protected void Timer1_Tick(object sender, EventArgs e)
        {
            Label3.Text = "Current Time: " + DateTime.Now.ToString("hh:mm:ss tt");
        }
    }
}
