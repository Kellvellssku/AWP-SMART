﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter the first number: ");
        double num1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter the second number: ");
        double num2 = Convert.ToDouble(Console.ReadLine());

        Console.WriteLine($"You entered: {num1} and {num2}");
        Console.WriteLine($"Addition:"+ (num1+num2));
        Console.WriteLine($"Subtraction:"+(num1 - num2));
        Console.WriteLine($"Multiplication:"+(num1 * num2));
        Console.WriteLine($"Divition:"+(num1 / num2));

        // Pause the console so the user can see the results
        Console.WriteLine("Press any key to exit...");
        Console.ReadKey();
    }
}