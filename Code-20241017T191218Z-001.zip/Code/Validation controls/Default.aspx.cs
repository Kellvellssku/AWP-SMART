﻿using System;
using System.Web.UI;

namespace WebApplication1
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // No additional logic needed for this example
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            // Check if the page is valid
            if (Page.IsValid)
            {
                // Here you would typically save the registration details to a database
                lblMessage.Text = "Registration successful!";
            }
            else
            {
                lblMessage.Text = "Please correct the errors and try again.";
            }
        }
    }
}
