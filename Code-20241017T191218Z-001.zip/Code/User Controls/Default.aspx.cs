﻿using System;

namespace YourNamespace
{
    public partial class Default : System.Web.UI.Page
    {
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            UserInfoControl.UserName = txtName.Text;
            UserInfoControl.UserEmail = txtEmail.Text;
        }
    }
}
