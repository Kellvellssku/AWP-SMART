﻿using System;

namespace YourNamespace
{
    public partial class UserInfo : System.Web.UI.UserControl
    {
        public string UserName
        {
            get { return lblName.Text; }
            set { lblName.Text = value; }
        }

        public string UserEmail
        {
            get { return lblEmail.Text; }
            set { lblEmail.Text = value; }
        }
    }
}
