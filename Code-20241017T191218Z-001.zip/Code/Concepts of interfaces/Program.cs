﻿using System;

// Define an interface named IMyInterface
interface MyInterface
{
    void Display();
}

// Implement the IMyInterface interface in a class called CallInterfaceA
class CallInterfaceA : MyInterface
{
    public void Display()
    {
        Console.WriteLine("Interface is called from CallInterfaceA");
    }
}

// Implement the IMyInterface interface in another class called CallInterfaceB
class CallInterfaceB : MyInterface
{
    public void Display()
    {
        Console.WriteLine("Interface method is called from CallInterfaceB");
    }
}

class Program
{
    public static void Main(string[] args)
    {
        // Create an instance of CallInterfaceA and call the Display method
        MyInterface objA = new CallInterfaceA();
        objA.Display();

        // Create an instance of CallInterfaceB and call the Display method
        MyInterface objB = new CallInterfaceB();
        objB.Display();

        // Wait for user input to close the console window
        Console.ReadKey();
    }
}
